package com.example.demo.controller;

import com.example.demo.components.Apply;
import org.springframework.web.bind.annotation.*;

@RestController //contorller ve response bodynin birleşmiş hali
@CrossOrigin(origins = "http://localhost:3000")
public class AlertController {


    @RequestMapping("/alerts") //bu url e sadece post request atılabilicek
    public Apply getAlerts(){
        Apply newApp = new Apply();
        //query

        return newApp;
    }

}

