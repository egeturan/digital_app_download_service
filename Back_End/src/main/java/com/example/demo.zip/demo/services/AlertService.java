package com.example.demo.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import yte.ege.alert.Backend.components.Alert;
import yte.ege.alert.Backend.components.AlertResponse;
import yte.ege.alert.Backend.repository.AlertRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class AlertService {

    final AlertRepository alertRepository;

    public AlertResponse addAlert(final Alert alert){
        Alert newAlert = null;
        AlertResponse alertResponse = new AlertResponse();

        List<Alert> alertList = alertRepository.findAll();
        int i = 0;
        boolean isPassed = true;
        while(i < alertList.size() && isPassed){

            if(alertList.size() > 0){
           if (alert.getName().equals(alertList.get(i).getName())) {
               System.out.println("This name already exist in database");
               isPassed = false;
           }
                i++;
           }
        }

        if(isPassed) {
            System.out.println("It has saved");
            try {
                newAlert = alertRepository.save(alert);
            } catch (Exception ex) {
                System.out.println(ex.getMessage());
            } finally {
                alertResponse.setResposeAlert(newAlert);
                alertResponse.setSituation(1);
                return alertResponse;
            }

        }else{
            alertResponse.setResposeAlert(new Alert());
            alertResponse.setSituation(0);
            return alertResponse;
        }
    }


    public List<Alert> getAlertByName(String name) {
        return alertRepository.findByName(name);
    }


    public List<Alert> deleteAlerts(Long id) {
        alertRepository.deleteById(id);
        return null;
    }

    public List<Alert> deleteAlerts(Alert alert) {
        alertRepository.delete(alert);
        return null;
    }


    public List<Alert> getAlerts() {

        return alertRepository.findAll();
    }

    public void deleteAll(){
        alertRepository.deleteAll();
      
    }

    public AlertResponse deleteAlertsById(String name) {
        List<Alert> deleteAlert =  alertRepository.findByName(name);

      AlertResponse alertResponse = new AlertResponse();
        alertResponse.setResposeAlert(new Alert());
        alertResponse.setSituation(0);
        if(deleteAlert.size() == 0){
            return alertResponse;
        }else {
            //Control prompts
            System.out.println("Size of the deleteAlert is: " + deleteAlert.size());
            System.out.println("Alert name that will be deleted: " + alertRepository.findByName(name).get(0).getName());
            //*****
            alertResponse.setResposeAlert(deleteAlert.get(0));
            while (deleteAlert.size() > 0) {
                alertRepository.delete(deleteAlert.get(0));
                deleteAlert.remove(0);
            }
            alertResponse.setSituation(1);
            return alertResponse;
        }
    }

    public AlertResponse findSearch(String name) {
        List<Alert> alertList = alertRepository.findAll();

        List<Alert> searchAlerts = new ArrayList<Alert>();
        int k = 0;

        for (int i = 0; i < alertList.size(); i++){
            String lowercaseFirst = alertList.get(i).getName();
            lowercaseFirst = lowercaseFirst.toLowerCase();
            System.out.println("Lowercased versions of names" + lowercaseFirst);

            //Convert to LowerCase
            if(lowercaseFirst.contains(name.toLowerCase())){
                searchAlerts.add(alertList.get(i));
                k++;
            }
        }

        AlertResponse alertResponse = new AlertResponse();
        alertResponse.setResposeAlert(new Alert());
        alertResponse.setResponseAlerts(searchAlerts);

        if(k == 0){ //found 0
            alertResponse.setSituation(0);
        }else{
            alertResponse.setSituation(1);
        }

        alertResponse.setResposeAlert(new Alert());

        System.out.println("Test for searched names of URLs");
        for (int i = 0; i < searchAlerts.size(); i++){
            System.out.println(" Alert is: " + searchAlerts.get(i));
        }


        return alertResponse;
    }
}
