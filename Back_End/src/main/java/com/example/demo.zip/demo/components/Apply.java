package com.example.demo.components;

public class Apply {

    String sid;
    String cid;

}
