# ADA STORE
This project started for Bilkent University CS353 Database Management Systems course
# To use the project
1.Install Node.js
2.Use cmd to enter into directory of the project
3.Write npm install
4.Write npm start
# UI
# DATABASE
