package com.example.demo.components;

public class Movie {

    int movie_id;
    String movie_name;
    String release_date;
    double imdb_rate;

    public int getMovie_id() {
        return movie_id;
    }

    public void setMovie_id(int movie_id) {
        this.movie_id = movie_id;
    }

    public String getMovie_name() {
        return movie_name;
    }

    public void setMovie_name(String movie_name) {
        this.movie_name = movie_name;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public double getImdb_rate() {
        return imdb_rate;
    }

    public void setImdb_rate(double imdb_rate) {
        this.imdb_rate = imdb_rate;
    }






}
