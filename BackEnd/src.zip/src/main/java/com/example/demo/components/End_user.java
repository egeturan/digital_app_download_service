package com.example.demo.components;

public class End_user {
    int user_id;
}
