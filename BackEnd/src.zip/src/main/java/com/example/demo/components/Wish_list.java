package com.example.demo.components;

public class Wish_list {
    int user_id;
    int app_id;
}
