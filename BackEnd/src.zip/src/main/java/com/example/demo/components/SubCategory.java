package com.example.demo.components;

public class SubCategory {
    int super_category_id;

    public int getSuper_category_id() {
        return super_category_id;
    }

    public void setSuper_category_id(int super_category_id) {
        this.super_category_id = super_category_id;
    }

    public int getSub_category_id() {
        return sub_category_id;
    }

    public void setSub_category_id(int sub_category_id) {
        this.sub_category_id = sub_category_id;
    }

    int sub_category_id;

}
