package com.example.demo.components;

public class Editor extends User{
    String user_id;
    int salary;

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }


}
