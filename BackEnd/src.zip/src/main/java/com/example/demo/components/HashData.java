package com.example.demo.components;

public class HashData {
    public String getHashData() {
        return hashData;
    }

    public void setHashData(String hashData) {
        this.hashData = hashData;
    }

    String hashData;
}
