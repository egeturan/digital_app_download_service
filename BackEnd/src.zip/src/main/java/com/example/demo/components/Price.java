package com.example.demo.components;

public class Price {

    private int lowwer_price;
    private int upper_price;

    public int getLowwer_price() {
        return lowwer_price;
    }

    public void setLowwer_price(int lowwer_price) {
        this.lowwer_price = lowwer_price;
    }

    public int getUpper_price() {
        return upper_price;
    }

    public void setUpper_price(int upper_price) {
        this.upper_price = upper_price;
    }



}
