package com.example.demo.components;

public class Has_req {
    int app_id;

    int RAM;
    String CPU;
    String OS_version;

    public int getApp_id() {
        return app_id;
    }

    public void setApp_id(int app_id) {
        this.app_id = app_id;
    }

    public int getRAM() {
        return RAM;
    }

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }

    public String getCPU() {
        return CPU;
    }

    public void setCPU(String CPU) {
        this.CPU = CPU;
    }

    public String getOS_version() {
        return OS_version;
    }

    public void setOS_version(String OS_version) {
        this.OS_version = OS_version;
    }

}
